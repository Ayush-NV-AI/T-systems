# Day 3 — Architecture, Documentation & Review

Two labs. Everything you need is in this folder.

## Starting a lab

**Windows:** double-click `START-HERE.bat` inside the lab folder.
**Mac / Linux:** double-click `START-HERE.command` inside the lab folder.

The first run takes a minute while it sets up. After that it is instant.
Your browser opens automatically. Close the black window to stop the app.

If it will not start, open `INSTALL-TROUBLESHOOTING.md` in the same
folder. The two errors people actually hit are in there with their fixes.

---

## Lab 3.1 — `3-architecture/`

**55 minutes.** Decide where the data lives, write it down, then make it
work.

1. Read `FEATURE-BRIEF.md` first. It has your real constraints.
2. Ask an assistant for four options. Reject any that ignores a
   constraint you stated.
3. Build a trade-off matrix for the two strongest.
4. Fill in `ADR-TEMPLATE.md`. Save it as `ADR-001-project-storage.md`.
5. Ask the model to argue against your decision. Add what lands.
6. Then make `add_project()` survive a restart. It is about fifteen
   lines.

**Done when:** your ADR has at least two negative consequences you would
rather not have written down, and a project you add is still there after
you restart the app.

The ADR matters more than the code. The code is how you find out whether
the ADR was honest.

---

## Lab 3.2 — `4-review/`

**55 minutes.** Two parts.

### Part one — document

1. Read `scoring.py`. It decides the order projects appear in. It is
   deliberately hard to read.
2. Generate docstrings for every function.
3. **Verify each one by running the code.** Pick an input, predict the
   output from your docstring, check whether the code agrees. Reading is
   not verifying.
4. Generate a sequence diagram of the main flow. Correct it.
5. Write the README yourself. The "why" is not in the code.

There are at least three things in that file that do not behave the way
the obvious reading suggests. If your docstrings mention none of them,
you documented the story rather than the code.

### Part two — review

1. Open `CHANGE-TO-REVIEW.md`. Another pair has proposed a change.
2. Run an AI review of it. Tell it to skip anything a linter covers.
3. Triage every comment into **act now / judge / ignore**. Write down
   how many landed in each pile.
4. Add **one comment of your own that the AI could not have made.**

Step 4 is the assessment. If you cannot find one, either the change is
trivial or you are reviewing at the same level as the machine — and both
of those are useful things to know about yourself.

---

## What to keep

Keep this whole folder. Tomorrow scans what you have written this week.
