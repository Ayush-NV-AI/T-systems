# If the app won't start — two known errors and their fixes

Keep this open during the lab. Both errors happen at install time, before
Streamlit ever runs. Neither is caused by your code.

---

## Error 1 — pip says it can't find Streamlit, but lists it anyway

### What you see

```
ERROR: Could not find a version that satisfies the requirement streamlit>=1.59
(from versions: 0.47.4, ... 1.50.0, 1.51.0, 1.52.0, ... 1.63.0)
ERROR: No matching distribution found for streamlit>=1.59
```

This is confusing on purpose-looking. pip prints `1.59.0`, `1.60.0`,
`1.63.0` in its own "from versions" list, and then says no matching version
exists.

### Why it happens

Your pip is too old to read the metadata format those newer releases use.
It can see the version numbers in the index, but it can't parse the package
records, so it silently discards every release it doesn't understand and
then reports there is nothing left that matches.

It is a **pip** problem, not a Streamlit problem and not a network problem.

### The fix

Run these two commands from the lab folder. Note the explicit path to the
virtual environment's Python — do **not** activate the venv first.

**Windows (PowerShell or CMD):**

```
.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
.venv\Scripts\python.exe -m pip install streamlit
```

**macOS / Linux:**

```
./.venv/bin/python -m pip install --upgrade pip setuptools wheel
./.venv/bin/python -m pip install streamlit
```

Then start the app again with `START-HERE.bat` (Windows) or
`START-HERE.command` (macOS/Linux).

### Why the launcher didn't fix this for you

`START-HERE` does attempt `pip install --upgrade pip` quietly. If that
upgrade itself fails — usually because the very old pip can't fetch its own
replacement — the launcher moves on without a visible error. Running the
upgrade by hand shows you the real result.

---

## Error 2 — a wall of C compiler output, ending in a zlib error

### What you see

Long build output mentioning `Pillow`, then something like:

```
The headers or library files could not be found for zlib,
a required dependency when compiling Pillow from source.
ERROR: Failed building wheel for pillow
```

### Why it happens

You are on **Python 3.14**. Pillow (an image library Streamlit depends on)
did not yet publish a prebuilt package for 3.14 at the version being
requested, so pip fell back to compiling it from source — which needs a C
compiler and the zlib headers that most laptops don't have.

The error text talks about zlib, but zlib is not the real problem. The real
problem is that pip was pushed into a source build it should never have
attempted.

### The fix

Use Python 3.13, 3.12 or 3.11 for this lab.

`START-HERE` already prefers those versions and prints which one it chose.
If it printed 3.14, that means no older version was found on your machine.
Install Python 3.12 from python.org, then delete the `.venv` folder in the
lab directory and run `START-HERE` again so it builds a fresh environment
against the older interpreter.

### How to tell the two errors apart

| Symptom | It's this error |
|---|---|
| "Could not find a version that satisfies…" and a long version list | Error 1 — old pip |
| C compiler output, `Pillow`, `zlib`, "failed building wheel" | Error 2 — Python 3.14 |

---

## Still stuck after both fixes

Run this and send the output:

**Windows:** `.venv\Scripts\python.exe -m pip --version`
**macOS / Linux:** `./.venv/bin/python -m pip --version`

It prints the pip version and the Python version it is attached to — which
is the one piece of information that tells us which of the two problems you
are actually hitting.

If pip itself cannot reach the internet at all, the error reads
`Could not fetch URL` or `Connection timed out` rather than either message
above. That one is a corporate network/proxy issue and needs your IT
settings, not a fix in this folder.
