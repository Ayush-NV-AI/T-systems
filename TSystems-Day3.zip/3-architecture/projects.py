"""
Project data for the portfolio app.

RIGHT NOW: the project list is hard-coded in this file.

That was fine for a demo. It is not fine any more, because the app now
needs to do three things it cannot do:

  1. Let someone add a project without editing Python.
  2. Keep projects that someone adds, after the app restarts.
  3. Let two people look at the same project list.

Lab 3.1 is about deciding HOW to fix that — not about typing the fix.
"""

PROJECTS = [
    {
        "name": "Invoice Reconciler",
        "desc": "Matches supplier invoices against purchase orders and flags mismatches.",
        "tags": ["python", "api"],
        "status": "live",
        "owner": "Priya",
    },
    {
        "name": "Deploy Dashboard",
        "desc": "Single page showing what is deployed where, refreshed every minute.",
        "tags": ["devops", "dashboard"],
        "status": "live",
        "owner": "Marek",
    },
    {
        "name": "Ticket Triage Helper",
        "desc": "Suggests a queue and a priority for incoming support tickets.",
        "tags": ["python", "api"],
        "status": "pilot",
        "owner": "Sam",
    },
    {
        "name": "Rapid Tooling Scripts",
        "desc": "Small scripts the team reruns every sprint. Badly named, widely used.",
        "tags": ["rapid", "tooling"],
        "status": "live",
        "owner": "Priya",
    },
    {
        "name": "Notes Cleanup",
        "desc": "Tidies up meeting notes into a standard heading structure.",
        "tags": [],
        "status": "shelved",
        "owner": "Unassigned",
    },
]
