#!/bin/bash
cd "$(dirname "$0")" || exit 1

echo
echo " Starting the lab app..."
echo

PY=""
for V in python3.13 python3.12 python3.11 python3; do
  if command -v "$V" >/dev/null 2>&1; then PY="$V"; break; fi
done

if [ -z "$PY" ]; then
  echo " [X] No Python found. Install Python 3.12 from https://www.python.org/downloads/"
  read -r -p "Press Enter to close."
  exit 1
fi

echo " Using Python $($PY -c 'import sys;print(sys.version.split()[0])')"
echo

if [ ! -d ".venv" ]; then
  echo " First run - creating the environment. This takes a minute."
  "$PY" -m venv .venv || { echo " [X] Could not create the environment."; read -r -p "Press Enter to close."; exit 1; }
fi

VPY="./.venv/bin/python"

"$VPY" -m pip install --quiet --upgrade pip setuptools wheel
if ! "$VPY" -m pip install --quiet --only-binary=:all: -r requirements.txt; then
  echo
  echo " [X] Could not install Streamlit."
  echo
  echo "     If the message said \"Could not find a version that satisfies\""
  echo "     your pip is too old. Run these two lines:"
  echo
  echo "       ./.venv/bin/python -m pip install --upgrade pip setuptools wheel"
  echo "       ./.venv/bin/python -m pip install streamlit"
  echo
  echo "     If it mentioned Pillow, zlib or a compiler - you are on Python"
  echo "     3.14. Install Python 3.12, delete .venv and run this again."
  echo
  echo "     See INSTALL-TROUBLESHOOTING.md for both fixes in full."
  echo
  read -r -p "Press Enter to close."
  exit 1
fi

echo
echo " Opening in your browser. Press Ctrl+C to stop the app."
echo
"$VPY" -m streamlit run app.py
