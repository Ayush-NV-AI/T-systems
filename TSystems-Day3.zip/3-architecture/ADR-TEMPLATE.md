# ADR-001: Where project data lives

## Status

Proposed | Accepted — <date>

## Context

*You write this. The AI cannot — it is your team, your constraints, your
history.*

What is the situation? What forces are at play? Use the real numbers from
FEATURE-BRIEF.md. Two or three short paragraphs.

## Options considered

*Good use of AI. Ask it for options you did not think of.*

For each option: one line on what it is, one line on why it is or is not
a fit **for these constraints specifically**.

- **Option A** —
- **Option B** —
- **Option C** —
- **Option D** —

## Decision

*You write this. This is the whole point of the document.*

We will ________, because ________.

One paragraph. State it as a decision, not as a preference.

## Consequences

*Good use of AI — especially the negative ones you are motivated to
forget.*

**Positive**

-
-

**Negative** — at least two, and they must be real

-
-

**What would make us revisit this**

-

---

Owner: <your name>   ·   Date: <today>
