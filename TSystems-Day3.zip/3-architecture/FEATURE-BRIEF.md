# Feature brief — Lab 3.1

Read this before you prompt anything.

## What exists

A Streamlit page that shows the team's project portfolio. The project
list is hard-coded in `projects.py`. Everything the page needs goes
through four functions in `storage.py`.

## What is being asked for

> "Can people add their own projects? And can we stop losing them every
> time the app restarts?"

There is already an **Add a project** form on the page. It works — until
you restart the app, at which point the new project is gone.

## Your real constraints

These are not decoration. Reject any AI suggestion that ignores one.

| Constraint | The actual number or fact |
|---|---|
| Users | 8 people, same team, same office |
| Concurrent writers | Rarely more than one at a time |
| Volume | ~50 projects now, maybe 300 in two years |
| Who runs it | One person's laptop, started by double-clicking a file |
| Who maintains it | This team. Two people have never installed a database |
| Ops support | None. There is no platform team |
| Deadline | It should work by Friday |
| Compliance | Nothing sensitive. Internal project names only |

## The decision you have to make

**Where do projects live, and in what format?**

Some of the options you will be offered:

- A JSON file next to the app
- A CSV file
- SQLite (a database in a single file, no server)
- PostgreSQL or MySQL (a database with a server)
- A Google Sheet via an API
- Streamlit's own session state
- A hosted service like Airtable or Supabase

Several of these are defensible. At least two are clearly wrong for the
constraints above. **You have to say which you chose and why**, and — this
is the part people skip — **what you gave up**.

## What you produce

1. `ADR-001-project-storage.md` in this folder. Template is in
   `ADR-TEMPLATE.md`.
2. A working `add_project()` that survives a restart.

The ADR matters more than the code. The code is how you find out whether
the ADR was honest.
