"""
The seam.

Everything the app needs from "wherever projects live" goes through the
four functions below. Nothing else in the app touches the data directly.

Right now every function just uses the hard-coded list in projects.py,
which is why add_project() does not actually keep anything.

Your job in Lab 3.1 is NOT to make all four work perfectly. It is to
decide what should sit behind this seam, write that decision down, and
then implement enough of it that add_project() survives a restart.
"""

from projects import PROJECTS

# --- read side -------------------------------------------------------

def list_projects():
    """Return every project as a list of dicts."""
    return list(PROJECTS)


def get_project(name):
    """Return one project by name, or None."""
    for p in list_projects():
        if p["name"].lower() == name.lower():
            return p
    return None


# --- write side ------------------------------------------------------

def add_project(project):
    """
    Add a project.

    TODO (Lab 3.1): this appends to a list that is rebuilt from source
    every time the process starts, so the new project disappears on
    restart. Whatever you choose in your ADR goes here.
    """
    PROJECTS.append(project)
    return project


def delete_project(name):
    """
    Remove a project by name. Returns True if something was removed.

    TODO (Lab 3.1): same problem as add_project.
    """
    for i, p in enumerate(PROJECTS):
        if p["name"].lower() == name.lower():
            PROJECTS.pop(i)
            return True
    return False
