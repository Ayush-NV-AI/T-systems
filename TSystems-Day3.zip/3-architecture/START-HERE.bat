@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  Starting the lab app...
echo.

set "PY="
for %%V in (3.13 3.12 3.11) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1
    if !errorlevel! equ 0 set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys" >nul 2>&1
  if !errorlevel! equ 0 set "PY=python"
)
if not defined PY (
  echo  [X] No Python found.
  echo      Install Python 3.12 from https://www.python.org/downloads/
  echo      and tick "Add python.exe to PATH" during setup.
  pause
  exit /b 1
)

for /f "delims=" %%A in ('%PY% -c "import sys;print(sys.version.split()[0])"') do set "PYVER=%%A"
echo  Using Python %PYVER%
echo.

if not exist ".venv" (
  echo  First run - creating the environment. This takes a minute.
  %PY% -m venv .venv
  if errorlevel 1 (
    echo  [X] Could not create the environment.
    pause
    exit /b 1
  )
)

set "VPY=%CD%\.venv\Scripts\python.exe"

"%VPY%" -m pip install --quiet --upgrade pip setuptools wheel
"%VPY%" -m pip install --quiet --only-binary=:all: -r requirements.txt
if errorlevel 1 (
  echo.
  echo  [X] Could not install Streamlit.
  echo.
  echo      If the message above said "Could not find a version that
  echo      satisfies" - your pip is too old. Run these two lines:
  echo.
  echo        .venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
  echo        .venv\Scripts\python.exe -m pip install streamlit
  echo.
  echo      If it mentioned Pillow, zlib or a compiler - you are on
  echo      Python 3.14. Install Python 3.12, delete the .venv folder
  echo      and run this file again.
  echo.
  echo      See INSTALL-TROUBLESHOOTING.md for both fixes in full.
  echo.
  pause
  exit /b 1
)

echo.
echo  Opening in your browser. Close this window to stop the app.
echo.
"%VPY%" -m streamlit run app.py
pause
