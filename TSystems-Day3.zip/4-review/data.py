"""Project data, now with a last_touched date so scoring.py has something to work with."""

PROJECTS = [
    {
        "name": "Invoice Reconciler",
        "desc": "Matches supplier invoices against purchase orders and flags mismatches.",
        "tags": ["python", "api"],
        "status": "live",
        "owner": "Priya",
        "last_touched": "2026-09-12",
    },
    {
        "name": "Deploy Dashboard",
        "desc": "Single page showing what is deployed where, refreshed every minute.",
        "tags": ["devops", "dashboard"],
        "status": "live",
        "owner": "Marek",
        "last_touched": "2026-08-20",
    },
    {
        "name": "Ticket Triage Helper",
        "desc": "Suggests a queue and a priority for incoming support tickets.",
        "tags": ["python", "api"],
        "status": "pilot",
        "owner": "Sam",
        "last_touched": "2026-09-01",
    },
    {
        "name": "Rapid Tooling Scripts",
        "desc": "Small scripts the team reruns every sprint. Badly named, widely used.",
        "tags": ["rapid", "tooling"],
        "status": "live",
        "owner": "Priya",
        "last_touched": "2026-05-01",
    },
    {
        "name": "Notes Cleanup",
        "desc": "Tidies up meeting notes into a standard heading structure.",
        "tags": [],
        "status": "shelved",
        "owner": "Unassigned",
        "last_touched": None,
    },
    {
        "name": "Sprint Retro Bot",
        "desc": "Collects retro notes in chat and posts a summary. Shelved, but three tagged and recently touched.",
        "tags": ["python", "tooling", "rapid"],
        "status": "shelved",
        "owner": "Marek",
        "last_touched": "2026-09-04",
    },
]
