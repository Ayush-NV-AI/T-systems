import streamlit as st

import scoring
from data import PROJECTS

st.set_page_config(page_title="Team Portfolio — ranked", layout="wide")

st.title("Team Portfolio")
st.caption(
    "The order of this list is decided by scoring.py. "
    "Nobody currently knows how. That is Lab 3.2."
)

show_scores = st.toggle("Show the score behind the order", value=True)
limit = st.slider("How many to show", min_value=1, max_value=len(PROJECTS),
                  value=len(PROJECTS))

ranked = scoring.rank(PROJECTS, limit)

st.divider()

for position, p in enumerate(ranked, start=1):
    box = st.container(border=True)
    with box:
        head, meta = st.columns([3, 1])
        with head:
            st.subheader(f"{position}. {p['name']}")
            st.write(p["desc"])
            st.caption("Tags: " + (" · ".join(p["tags"]) if p["tags"] else "none"))
        with meta:
            st.metric("Bucket", scoring.bucket(p))
            st.caption(f"Status: {p['status']}")
            st.caption(f"Last touched: {p['last_touched'] or 'never recorded'}")
            if show_scores:
                st.caption(f"Score: {scoring.score(p)}")

st.divider()
st.caption(f"Showing {len(ranked)} of {len(PROJECTS)} projects")
