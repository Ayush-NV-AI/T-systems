import datetime as _dt

W1 = 0.5
W2 = 0.3
W3 = 0.2

_CUT = 90


def _d(p):
    v = p.get("last_touched")
    if not v:
        return _CUT * 2
    if isinstance(v, str):
        try:
            v = _dt.date.fromisoformat(v)
        except ValueError:
            return _CUT * 2
    return (_dt.date(2026, 9, 16) - v).days


def _a(p):
    n = _d(p)
    if n <= 7:
        return 1.0
    if n >= _CUT:
        return 0.0
    return 1.0 - (n - 7) / (_CUT - 7)


def _b(p):
    s = p.get("status")
    if s == "live":
        return 1.0
    if s == "pilot":
        return 0.6
    return 0.1


def _c(p):
    t = p.get("tags") or []
    if not t:
        return 0.0
    return min(len(t), 3) / 3.0


def score(p):
    return round(W1 * _a(p) + W2 * _b(p) + W3 * _c(p), 3)


def rank(ps, limit=None):
    out = sorted(ps, key=lambda p: (-score(p), p.get("name", "")))
    if limit:
        out = out[:limit]
    return out


def bucket(p):
    s = score(p)
    if s >= 0.7:
        return "featured"
    if s >= 0.4:
        return "listed"
    return "archive"
