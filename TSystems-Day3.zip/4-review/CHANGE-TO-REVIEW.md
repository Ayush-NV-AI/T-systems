# The change you are reviewing — Lab 3.2, part two

Another pair has proposed a change to `scoring.py`. It has not been merged.
Your job is to review it the way you would review a colleague's work.

There is no pull request and no GitHub. The proposed change is written out
below, in the same form a PR would show it.

---

## What they say it does

> "Adds a `featured_only` flag to `rank()` so the homepage can show just
> the featured projects. Also fixes the bug where `limit=0` returned
> everything."

---

## The proposed new `rank()`

```python
def rank(ps, limit=None, featured_only=False):
    out = sorted(ps, key=lambda p: (-score(p), p.get("name", "")))
    if featured_only:
        out = [p for p in out if bucket(p) == "featured"]
    if limit is not None:
        out = out[:limit]
    return out
```

## The proposed new `bucket()`

```python
def bucket(p):
    s = score(p)
    if s > 0.7:
        return "featured"
    if s > 0.4:
        return "listed"
    return "archive"
```

---

## How to review it

1. Run an AI review of this change. Give it `scoring.py` as context and
   tell it to skip anything a formatter or linter would catch.
2. Triage every comment it makes into **act now / judge / ignore**.
   Count each pile.
3. Add **one comment of your own that the AI could not have made.**

That last step is the assessment. Write it down.

---

## A hint about where to look

The author described two changes. Count how many things actually changed
in `bucket()`.
