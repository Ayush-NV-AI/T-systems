# Team AI Playbook — <team name>

Owner: ____________   ·   Date: ____________   ·   Review date: ____________

> Two pages. If it runs longer, cut it. An unread playbook and no playbook
> produce identical outcomes.

---

## 1 · Tool selection

| | |
|---|---|
| Tools we use | |
| Tier / licence | |
| Who pays | |
| How a new joiner gets access on day one | |

---

## 2 · When to use what

Our decision framework. What we reach for, and — more importantly — what
we don't.

| Task type | Our position |
|---|---|
| | |
| | |
| | |

**What we do not delegate** *(from the list on the board)*

-
-
-

---

## 3 · Review checklist for AI-assisted changes

What a reviewer checks specifically when the change was AI-assisted.

- [ ] Does the diff match the description? Count the things that changed
- [ ] Any files touched that weren't in scope?
- [ ] Any test or assertion edited that wasn't asked for?
- [ ] Any new dependency — does it exist, and is it the one we meant?
- [ ] Any decision made that nobody asked for?
- [ ]

---

## 4 · Guardrails

| | |
|---|---|
| Branch policy for agent work | |
| What an agent may edit | |
| What always needs approval | |
| What is never delegated | |

---

## 5 · Verification gate

| | |
|---|---|
| What runs, and where | |
| What blocks a merge | |
| Who tunes the ruleset when it gets noisy | |
| How a suppression gets justified | |

> Note from Thursday: a noisy gate gets bypassed, and a bypassed gate is
> worse than no gate. Whoever owns tuning needs the time to do it.

---

## 6 · Metrics and cadence

| Metric | How it's collected | By whom | How often |
|---|---|---|---|
| Cycle time | | | |
| PR turnaround | | | |
| Defect escape rate | | | |
| Developer sentiment | | | |

**Baseline:** ____________________________________________

**Continue if:** ____________________________________________

**Stop if:** ____________________________________________

| Cadence | When | Who runs it |
|---|---|---|
| Weekly — 15 min | | |
| Monthly — 30 min | | |
| Quarterly — 1 hr | | |

---

## Making it stick — the configuration version

Each section above can become a file in the repo, so nobody has to
remember it.

| Playbook section | Becomes |
|---|---|
| 2 · When to use what | `CLAUDE.md` |
| 3 · Review checklist | a skill — `.claude/skills/review/SKILL.md` |
| 4 · Guardrails | permissions in `.claude/settings.json` |
| 5 · Verification gate | a `PostToolUse` hook |
| All of it, distributed | an internal plugin |

Start with `CLAUDE.md`. It takes ten minutes and everyone who clones the
repo gets it.
