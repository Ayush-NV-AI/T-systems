# AI tooling rollout — <team name>

**One page.** If it doesn't fit, it won't be read.

---

## The team

Size ______ · Stack ____________ · Current delivery pressure ____________

Who wants this: ____________   Who is sceptical: ____________

---

## The four metrics

| Metric | Source | Who pulls it | How often |
|---|---|---|---|
| Cycle time — first commit to merged | | | |
| PR turnaround — opened to first review | | | |
| Defect escape rate | | | |
| Developer sentiment — one question | | | |

> Not lines of code. Not suggestions accepted. Not prompts sent. Those
> measure activity, and activity is not value.

---

## Baseline

What we collect: ____________________________________________

For how long: ____________   Starting: ____________

*If you have no clean baseline because the tools are already in use, write
that here and say so out loud. It's defensible. Pretending otherwise isn't.*

---

## Coaching rhythm

| | Who | When |
|---|---|---|
| Pairing — enthusiast with sceptic, sceptic drives | | |
| Show and tell — 15 min, one win and one failure | | |
| Prompt library owner | | |

*A name, not a team. "Whoever has time" is nobody.*

---

## The two thresholds

**We continue if:** ____________________________________________

**We stop if:** ____________________________________________

*Write both before you see any data. This is what stops the result being
whatever you already wanted.*

---

## Review date

____________  *(twelve weeks out, in the calendar, now)*

---

## The paragraph I'd send my manager

Three sentences: what I want, what it costs, what I'll report back and when.

________________________________________________________________

________________________________________________________________

________________________________________________________________
