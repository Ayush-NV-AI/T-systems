# Lab 4.2 — what to do

**45 minutes.** Four steps. Do not skip step 2.

---

## Step 1 — Scan

From this folder:

```
.venv\Scripts\python.exe -m bandit -r .              (Windows)
./.venv/bin/python -m bandit -r .                    (Mac / Linux)
```

`START-HERE` already installed the scanner.

For a summary you can read:

```
python -m bandit -r . -f screen
```

You should get **14 findings** across high, medium and low.

That is the whole of step 1. Everything else today is about what to do
with that list.

---

## Step 2 — Triage

**This is the actual skill, and it is the step people skip.**

Open `TRIAGE-SHEET.md`. Put every finding in one of three piles:

| Pile | Means |
|---|---|
| **ACT NOW** | Real, exploitable or data-losing. Fix before this ships |
| **JUDGE** | Real finding, but whether it matters depends on context |
| **IGNORE** | Noise, or a rule that needs tuning for this codebase |

For each one, write **one sentence** on why it is in that pile. A pile
with no reasons is not a triage, it is a sort.

Watch for this: some findings are flagged just because a module is
*imported*, not because of how it is *used*. Those are the ones that tell
you the ruleset needs tuning.

---

## Step 3 — Fix the ACT NOW pile

Fix them in `admin.py`. Re-run the scan after each fix.

**The rule from Day 3 applies:** you may not apply a fix until you can say
in one sentence what the attack was. "The scanner told me to" is not a
reason.

Use an assistant to help — but the scanner is the judge, not the
assistant.

---

## Step 4 — Check the dependencies

`requirements-suggested.txt` is a list an assistant produced when asked
what packages this app would need. **Nobody has checked it.**

For each package, answer three questions:

1. **Does it exist?** Check on `pypi.org/project/<name>`, or run
   `pip index versions <name>`.
2. **Is it the one you meant?** Look at the repository link and the
   author. Do they match each other?
3. **What licence is it under?** If none is declared, you cannot use it —
   that is not a technicality.

**Do not install anything from that file.** Checking is the exercise.
Installing an unverified package is the failure mode the whole module is
about.

Record what you find in `TRIAGE-SHEET.md`.

> Two of those seven entries will not survive the check. They fail for
> two completely different reasons, and the second one is more
> interesting than the first.

---

## Done when

- Every ACT NOW finding is fixed, and you can state the attack for each
- Every remaining finding is consciously accepted, in writing
- Every dependency is verified, or flagged with a reason

## The question to bring to the debrief

You predicted which of this week's code would scan worst. Hold that
prediction — your trainer has the answer for the other folders.
