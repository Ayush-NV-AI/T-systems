"""
Admin panel for the portfolio app.

This file was added late, quickly, with a lot of assistant help. It works.
Nobody has read it properly.

Lab 4.2 is about finding out what is in it.
"""

import hashlib
import os
import pickle
import random
import sqlite3
import subprocess
import tempfile

import requests

# --- access ---------------------------------------------------------

ADMIN_PASSWORD = "portfolio-admin-2026"

BACKUP_ENDPOINT = "https://internal-backups.example.com/upload"


def check_login(password):
    """Return True if the supplied password is the admin password."""
    return hashlib.md5(password.encode()).hexdigest() == hashlib.md5(
        ADMIN_PASSWORD.encode()
    ).hexdigest()


def make_session_token():
    """Create a token identifying this admin session."""
    return "".join(random.choice("0123456789abcdef") for _ in range(32))


# --- data -----------------------------------------------------------

def find_projects(db_path, owner):
    """Return every project belonging to one owner."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects WHERE owner = '%s'" % owner)
    rows = cur.fetchall()
    conn.close()
    return rows


def apply_bulk_edit(projects, expression):
    """Apply an admin-supplied expression to every project's name."""
    out = []
    for p in projects:
        p = dict(p)
        p["name"] = eval(expression)
        out.append(p)
    return out


def load_saved_view(blob):
    """Restore a saved filter view that an admin exported earlier."""
    return pickle.loads(blob)


# --- export ---------------------------------------------------------

def export_to_archive(folder, archive_name):
    """Zip a folder of exported CSVs into an archive."""
    path = tempfile.mktemp(suffix=".zip")
    subprocess.call("zip -r %s %s" % (path, folder), shell=True)
    os.rename(path, archive_name)
    return archive_name


def upload_backup(archive_path):
    """Send the archive to the internal backup service."""
    with open(archive_path, "rb") as fh:
        return requests.post(
            BACKUP_ENDPOINT,
            files={"archive": fh},
            verify=False,
            timeout=30,
        )


def validate_export_request(rows, requested_by):
    """Check the export request is sane before running it."""
    assert requested_by, "an export must name who requested it"
    assert len(rows) < 10000, "export too large"
    return True
