@echo off
cd /d "%~dp0"
echo.
echo  Scanning this folder with Bandit...
echo.
if not exist ".venv" (
  echo  [X] Run START-HERE.bat first - it sets up the environment.
  pause
  exit /b 1
)
"%CD%\.venv\Scripts\python.exe" -m bandit -r . -x .venv
echo.
echo  Above: every finding, with a severity and a test ID.
echo  Now open TRIAGE-SHEET.md and sort them.
echo.
pause
