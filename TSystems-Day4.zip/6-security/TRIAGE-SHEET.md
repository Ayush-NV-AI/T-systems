# Triage sheet — Lab 4.2

Names: ______________________

## Part 1 — Scan results

| | High | Medium | Low | Total |
|---|---|---|---|---|
| `6-security` | | | | |

**Your prediction from before the lab — which of this week's code did you
think would scan worst?**

---

## Part 2 — Triage

### ACT NOW

| Test ID | Line | What the attack actually is (one sentence) |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |

### JUDGE

| Test ID | Line | Why it depends, and what you decided |
|---|---|---|
| | | |
| | | |
| | | |

### IGNORE

| Test ID | Line | Why this is noise here |
|---|---|---|
| | | |
| | | |

**Counts:** act ____ · judge ____ · ignore ____

If most findings landed in IGNORE, what would you change about the
ruleset rather than the code?

---

## Part 3 — Fixes

| Test ID | The fix | Re-scanned clean? |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |

---

## Part 4 — Dependencies

| Package | Exists? | Repo and author agree? | Licence | Verdict |
|---|---|---|---|---|
| streamlit | | | | |
| pandas | | | | |
| requests | | | | |
| python-dateutil | | | | |
| streamlit-aggrid-pro | | | | |
| csvkit-lite | | | | |
| tabulate | | | | |

**The two that failed, and why each one failed differently:**

1.

2.

**What would have caught this before it reached a developer's machine?**

---

## Part 5 — The one you write yourself

One finding the scanner did **not** report, that you think is a real
problem in this code:
