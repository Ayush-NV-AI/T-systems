import streamlit as st

import admin
import storage

st.set_page_config(page_title="Team Portfolio — admin", layout="wide")

st.title("Team Portfolio")
st.caption(
    "Same app as yesterday, plus an admin panel that was added in a hurry "
    "with a lot of assistant help."
)

# ---------------------------------------------------------------- admin

with st.sidebar:
    st.subheader("Admin")
    pw = st.text_input("Admin password", type="password")
    if pw:
        if admin.check_login(pw):
            st.success("Signed in.")
            st.caption(f"Session token: {admin.make_session_token()[:8]}…")
        else:
            st.error("Wrong password.")
    st.divider()
    st.caption(
        "Everything in the sidebar is powered by admin.py. "
        "That is the file Lab 4.2 is about."
    )

# --------------------------------------------------------------- filter

projects = storage.list_projects()

left, right = st.columns([2, 1])
with left:
    search = st.text_input("Search", placeholder="name or description")
with right:
    only_live = st.checkbox("Live projects only", value=False)


def matches(project):
    if only_live and project["status"] != "live":
        return False
    if search.strip():
        needle = search.strip().lower()
        if needle not in project["name"].lower() and needle not in project["desc"].lower():
            return False
    return True


shown = [p for p in projects if matches(p)]

# --------------------------------------------------------------- render

st.divider()

for p in shown:
    box = st.container(border=True)
    with box:
        head, meta = st.columns([3, 1])
        with head:
            st.subheader(p["name"])
            st.write(p["desc"] or "_No description._")
        with meta:
            st.metric("Status", p["status"])
            st.caption(f"Owner: {p['owner']}")
        st.caption("Tags: " + (" · ".join(p["tags"]) if p["tags"] else "none"))

st.divider()
st.caption(f"Showing {len(shown)} of {len(projects)} projects")
