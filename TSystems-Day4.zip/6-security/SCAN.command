#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo
echo " Scanning this folder with Bandit..."
echo
if [ ! -d ".venv" ]; then
  echo " [X] Run START-HERE.command first - it sets up the environment."
  read -r -p "Press Enter to close."
  exit 1
fi
./.venv/bin/python -m bandit -r . -x .venv
echo
echo " Above: every finding, with a severity and a test ID."
echo " Now open TRIAGE-SHEET.md and sort them."
echo
read -r -p "Press Enter to close."
