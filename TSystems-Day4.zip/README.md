# Day 4 — Agentic Workflows & Governance

Two labs. Everything you need is in this folder.

## Starting a lab

**Windows:** double-click `START-HERE.bat` inside the lab folder.
**Mac / Linux:** double-click `START-HERE.command`.

First run takes a minute. Browser opens automatically. Close the black
window to stop the app.

If it will not start, open `INSTALL-TROUBLESHOOTING.md` in the same folder.

---

## Lab 4.1 — `5-agent/`

**65 minutes.** Implement a feature with an agent, approving every step.

1. Read `SPEC.md`. All of it, before you prompt anything.
2. Answer the four questions in writing: blast radius, definition of
   done, existing patterns, out of scope.
3. **Run in plan mode first. Count the files.** If it touches files you
   did not expect, reject it and re-scope before it starts.
4. Execute with approval at every step. **Do not enable auto-approve** —
   however tempting it gets around minute forty.
5. Fill in `INTERVENTION-LOG.md` **as you go**, not at the end.
6. Read the final diff file by file. Compare it to what the agent said
   it did.

**Watch for:** edits to files you did not name · two fixes that undo each
other · a summary that omits a change · a silent decision about the
counter.

**Done when:** the feature works by your own definition of done, and you
can account for every line in the diff — including the ones you did not
ask for.

The app already persists projects, so you are not blocked if you did not
finish yesterday.

**Keep this folder.** It gets scanned this afternoon.

---

## Lab 4.2 — `6-security/`

**45 minutes.** Read `TASKS.md`. Four steps.

1. **Scan.** Double-click `SCAN`. That is the whole step — 14 findings.
2. **Triage.** Every finding into act now / judge / ignore, with one
   sentence each on why. **This is the actual skill.**
3. **Fix** the act-now pile. You may not apply a fix until you can say in
   one sentence what the attack was.
4. **Check the dependencies** in `requirements-suggested.txt`.

> **Do not install anything from `requirements-suggested.txt`.**
> Checking is the exercise. Installing an unverified package is exactly
> the failure mode this module is about.

Record everything in `TRIAGE-SHEET.md`.

**Done when:** every act-now finding is fixed and explained, every
remaining finding is consciously accepted in writing, and every
dependency is verified or flagged with a reason.

---

## For tomorrow

Bring one honest opinion: **which task type would you now refuse to
delegate?**

We start with that question, going round the room.
