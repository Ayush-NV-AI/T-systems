"""Reference solution for Lab 3.1 — JSON file storage behind the same seam."""

import json
import os
import tempfile

from projects import PROJECTS as SEED

DATA_FILE = os.path.join(os.path.dirname(__file__), "projects.json")


def _load():
    if not os.path.exists(DATA_FILE):
        _save(SEED)
        return list(SEED)
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return list(SEED)


def _save(projects):
    # write to a temp file in the same directory, then replace — so a crash
    # mid-write cannot leave a truncated projects.json behind
    d = os.path.dirname(DATA_FILE)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(projects, fh, indent=2)
        os.replace(tmp, DATA_FILE)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def list_projects():
    return _load()


def get_project(name):
    for p in list_projects():
        if p["name"].lower() == name.lower():
            return p
    return None


def add_project(project):
    projects = _load()
    projects.append(project)
    _save(projects)
    return project


def delete_project(name):
    projects = _load()
    for i, p in enumerate(projects):
        if p["name"].lower() == name.lower():
            projects.pop(i)
            _save(projects)
            return True
    return False
