# Feature spec — Lab 4.1

You are going to have an agent implement this. **Read it fully before you
prompt anything.**

---

## What the app does today

A Streamlit portfolio page. Projects live in `projects.json` and survive a
restart. You can add projects, search them, and filter to live ones only.

Three files:

| File | What it holds |
|---|---|
| `app.py` | The page — form, filters, rendering, the counter |
| `storage.py` | The seam — load, get, add, delete |
| `projects.py` | The seed data used the first time it runs |

## What is being asked for

> "Some projects are finished but we don't want to delete them. Can we
> archive them instead?"

### Requirements

1. Every project card gets an **Archive** action.
2. Archived projects are **hidden by default**.
3. A toggle shows archived projects when someone wants to see them.
4. An archived project can be **un-archived**.
5. The archive state **survives a restart**, like everything else.
6. The counter at the bottom stays truthful.

---

## Before you prompt: answer these four

Slide 5 gives you the questions. Write your answers down — you are going to
paste them into the task.

**Blast radius.** Which files may it touch? Which must it not?

**Definition of done.** What will you actually do to prove it works?
Name the clicks.

**Existing patterns.** There is already a filter (`Live projects only`)
and already a persisted field. What should the agent copy rather than
invent?

**Out of scope.** What must it leave alone?

---

## The thing this spec does not tell you

Read requirement 2 and requirement 6 together.

The counter currently reads `Showing X of Y projects`.

Once some projects are hidden by default, **what are X and Y?** Is Y all
projects, or all non-archived projects? Is an archived project "missing"
from the count or excluded from it?

**The spec does not say.** That is deliberate.

An agent will decide this silently and you will not notice unless you
look. Decide it yourself first, write it into your task, and then check
whether the agent did what you said.

---

## Done when

- The feature works, by your own definition of done
- You can account for **every line** in the diff, including lines you did
  not ask for
- You have written down every moment you had to intervene, and why

Keep this folder. It gets scanned this afternoon.
