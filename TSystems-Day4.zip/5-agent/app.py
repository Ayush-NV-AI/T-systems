import streamlit as st

import storage

st.set_page_config(page_title="Team Portfolio", layout="wide")

st.title("Team Portfolio")
st.caption("Projects are stored in projects.json and survive a restart.")

# ---------------------------------------------------------------- add

with st.expander("Add a project", expanded=False):
    with st.form("add_project", clear_on_submit=True):
        name = st.text_input("Name")
        desc = st.text_area("What it does", height=80)
        tags_raw = st.text_input("Tags (comma separated)", placeholder="python, api")
        status = st.selectbox("Status", ["live", "pilot", "shelved"])
        owner = st.text_input("Owner", placeholder="Your name")
        submitted = st.form_submit_button("Add project")

    if submitted:
        if not name.strip():
            st.error("A project needs a name.")
        elif storage.get_project(name.strip()):
            st.error(f"There is already a project called {name.strip()!r}.")
        else:
            storage.add_project(
                {
                    "name": name.strip(),
                    "desc": desc.strip(),
                    "tags": [t.strip() for t in tags_raw.split(",") if t.strip()],
                    "status": status,
                    "owner": owner.strip() or "Unassigned",
                }
            )
            st.success(f"Added {name.strip()!r}.")

# ------------------------------------------------------------- filter

projects = storage.list_projects()

left, right = st.columns([2, 1])
with left:
    search = st.text_input("Search", placeholder="name or description")
with right:
    only_live = st.checkbox("Live projects only", value=False)


def matches(project):
    if only_live and project["status"] != "live":
        return False
    if search.strip():
        needle = search.strip().lower()
        if needle not in project["name"].lower() and needle not in project["desc"].lower():
            return False
    return True


shown = [p for p in projects if matches(p)]

# ------------------------------------------------------------- render

st.divider()

for p in shown:
    box = st.container(border=True)
    with box:
        head, meta = st.columns([3, 1])
        with head:
            st.subheader(p["name"])
            st.write(p["desc"] or "_No description._")
        with meta:
            st.metric("Status", p["status"])
            st.caption(f"Owner: {p['owner']}")
        if p["tags"]:
            st.caption("Tags: " + " · ".join(p["tags"]))
        else:
            st.caption("Tags: none")

st.divider()
st.caption(f"Showing {len(shown)} of {len(projects)} projects")
