# T-Systems · Day 2 — Start Here

Everything for today is in this folder. Two labs, two folders.

```
1-refactor\    Lab 2.1 — tidy the page without changing it
2-debug\       Lab 2.2 — find the bug you can see
```

---

## Getting your app running — pick the first one that works

### Option 1 — Double-click (try this first)

Open the lab folder and double-click:

> **Python version matters.** 3.11, 3.12 or 3.13 all work. If you have 3.14
> the install may fail — see Option 3 below. The launcher tells you which
> version it picked when it starts.

| Your machine | Double-click this |
|---|---|
| **Windows** | `START-HERE.bat` |
| **Mac** | `START-HERE.command` |
| **Linux** | `START-HERE.command` |

A black window opens and stays open — **that's normal, leave it there.** The
first run takes a minute or two while it installs. Then your browser opens
automatically at your app.

**To stop it later:** close the black window.

**Mac: "cannot be opened because it is from an unidentified developer"**
Right-click `START-HERE.command` → **Open** → **Open**. Once only.

---

### Option 2 — If the double-click fails

Open a terminal **in the lab folder** and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open http://localhost:8501

---

### Option 3 — If the install fails

Read the last few lines of the black window.

**"no prebuilt version for your Python" / a long red wall mentioning `pillow`,
`zlib` or "building wheel"**
Your Python is newer than some packages support yet. Python **3.12** is the
safest version for this workshop. Either install 3.12 from
[python.org/downloads](https://www.python.org/downloads/release/python-3128/)
— tick *Add Python to PATH* — or tell the trainer and pair with a neighbour.

**Anything mentioning proxy, SSL, timeout or connection**
Your network is blocking pip. **Tell the trainer — don't spend the lab on it.**
You'll be paired with someone and you'll still do every step; you just won't be
the one typing.

---

## Which lab, when

| Time | Folder | What you're doing |
|---|---|---|
| Afternoon, first half | `1-refactor` | Make the page cleaner without changing what it does |
| Afternoon, second half | `2-debug` | Find and explain a bug |

Each folder has its own `README.md` with every step and every prompt written
out. **Open it before you start.**

---

## The two rules for today

**Lab 2.1 — behaviour must not change.** If you find something that looks
like a bug, *write it down, don't fix it.* Fixing and tidying in one go is
how things break quietly.

**Lab 2.2 — no fix until you can explain it.** You may not apply a fix until
you can say, in one sentence, why the bug causes that exact symptom. Finding
it by luck doesn't count.

---

## If you get stuck

Ask. That's what the afternoon is for. But try to describe the problem
precisely first — *what you did, what you expected, what happened* — because
that description is half the debugging skill we're practising today.
