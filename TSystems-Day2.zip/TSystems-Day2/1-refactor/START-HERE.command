#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
echo "============================================"
echo "  Starting your app."
echo "  First run takes a minute or two."
echo "  Leave this window open."
echo "============================================"
echo

hold() { read -r -p "Press Enter to close."; }

# --- find a Python we can use ---------------------------------------------
PYEXE=""
for c in python3.13 python3.12 python3.11 python3 python; do
  command -v "$c" >/dev/null 2>&1 && { PYEXE="$c"; break; }
done
if [ -z "$PYEXE" ]; then
  echo "[X] Python is not installed."
  echo "    macOS:  brew install python@3.12"
  echo "    Linux:  sudo apt install python3 python3-venv"
  hold; exit 1
fi

PYVER=$("$PYEXE" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)
echo "Using Python $PYVER  ($PYEXE)"
echo

# --- create the environment (no activation needed) -------------------------
if [ ! -x ".venv/bin/python" ]; then
  echo "Creating a private Python environment..."
  "$PYEXE" -m venv .venv || { echo "[X] Could not create the environment. Tell the trainer."; hold; exit 1; }
fi

# --- every command below calls the venv python directly --------------------
VPY="$PWD/.venv/bin/python"

echo "Installing Streamlit (first run only)..."
"$VPY" -m pip install --quiet --upgrade pip
if ! "$VPY" -m pip install --quiet --only-binary=:all: -r requirements.txt; then
  echo
  echo "[X] Install failed."
  echo
  echo "    Most likely cause: your Python version is very new and some"
  echo "    packages have no prebuilt version for it yet."
  echo "    Your Python is $PYVER - Python 3.12 is the safest."
  echo
  echo "    Second possibility: your network is blocking pip."
  echo
  echo "    Tell the trainer - do not spend the lab on this."
  hold; exit 1
fi

echo
echo "Opening your app in the browser..."
echo "To stop it later: press Ctrl+C, or close this window."
echo
"$VPY" -m streamlit run app.py
