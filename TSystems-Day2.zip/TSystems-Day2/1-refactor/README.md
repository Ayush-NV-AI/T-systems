# Lab 2.1 — Tidy the page without changing it

Your portfolio page grew a Projects section overnight. It works. It is also
one long file with everything jammed together.

Your job: make it something you'd be happy to show a colleague — **without
changing a single thing the page does.**

## Option A — no install needed (recommended)

1. Click the Replit link in chat
2. Sign in (Google or GitHub is fastest)
3. Click the green **Run** button
4. The page opens in the preview panel

## Option B — locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Opens at http://localhost:8501

---

## Step 1 — Describe what it does (8 min)

**Do not change anything yet.** Use the page. Click things. Type in the
search box. Type in the tag box. Try an empty search. Try a tag that
doesn't exist.

Write down ten short lines describing what it actually does. Plain English.

**Include anything that looks odd or wrong.** You are not judging it —
you are recording it.

> One of the projects behaves differently from the others. Find it.

## Step 2 — Turn your list into checks (17 min)

Paste your list into Claude Code with this prompt:

```
Here is a description of what my Streamlit app currently does:

<paste your ten lines>

Write a Python script called check.py that verifies each of these
behaviours against the current code in app.py, EXACTLY AS WRITTEN,
including any behaviour that looks like a bug. Do not correct anything.

Print PASS or FAIL for each check with a short label, and a summary
line at the end. Use plain Python — no test framework.
```

Then run it:

```bash
python check.py
```

### Hard gate — everything must PASS

If a check FAILS against the code you haven't touched yet, **your check is
wrong, not the app.** Fix the check. Do not go to step 3 until every line
says PASS.

## Step 3 — Split it up (28 min)

```
Split app.py into four files without changing any behaviour:
  data.py     the PROJECTS list and the skills data
  filters.py  the search and tag filtering logic, as functions
  calc.py     the calculate() function
  app.py      only the Streamlit page itself, importing from the others

Do not change what any of it does. Do not rename anything the user can
see. Do not add features. Do not "improve" anything I have not asked for.

Make one file at a time and stop after each so I can check the page
still works.
```

**After each file: reload the page and use it.** The page working is your test.

## Step 4 — Prove you didn't break it (10 min)

```bash
python check.py
```

Same results as step 2. Every line still PASS.

Reload the page one more time. It should look and behave exactly as it did
an hour ago — but the code behind it is now four clean files.

---

## Done when

- `check.py` gives the same output it gave before you refactored
- The page looks and behaves identically
- `app.py` is short enough to read in one screen

## Watch out for

The assistant will want to fix things you didn't ask it to fix. Read every
change before you accept it. If it did four things and you asked for one,
keep the one and discard the rest — don't argue with it.
