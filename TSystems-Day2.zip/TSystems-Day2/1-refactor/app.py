import streamlit as st

st.set_page_config(page_title="My Portfolio", page_icon="👋", layout="centered")

# --- Header ---
st.title("Hi, I'm Jordan Lee 👋")
st.subheader("Software Engineer")
st.write(
    "I build backend services and dabble in data tooling. "
    "This page grew a projects section overnight — and it shows."
)

st.header("About Me")
st.write(
    "5 years in backend development, mostly Python and Java. "
    "Currently exploring how AI coding assistants change day-to-day work."
)

st.header("Skills")
c1, c2, c3 = st.columns(3)
c1.metric("Python", "Advanced")
c2.metric("SQL", "Intermediate")
c3.metric("Docker", "Intermediate")

st.divider()

# --- Projects ---
st.header("Projects")

PROJECTS = [
    {"name": "Order Reporting Service", "desc": "Internal dashboard for sales ops.",
     "tags": ["python", "api", "dashboard"], "year": 2025},
    {"name": "Bookshelf API", "desc": "A tiny FastAPI app built in a workshop.",
     "tags": ["python", "api"], "year": 2026},
    {"name": "Rapid Prototyping Kit", "desc": "Scaffolding for quick internal demos.",
     "tags": ["rapid", "tooling"], "year": 2024},
    {"name": "Deploy Scripts", "desc": "One-command deploys for the staging box.",
     "tags": ["devops", "tooling"], "year": 2024},
    {"name": "Notes Cleanup", "desc": "Weekend script, never really finished.",
     "tags": [], "year": 2023},
]

search = st.text_input("Search projects", "")
tag = st.text_input("Filter by tag (try: api, tooling, python)", "")

shown = 0
for p in PROJECTS:
    if p["tags"]:
        ok = True
        if search != "":
            if search.lower() not in p["name"].lower() and search.lower() not in p["desc"].lower():
                ok = False
        if tag != "":
            if tag.lower() not in [t.lower() for t in p["tags"]]:
                ok = False
        if ok:
            shown = shown + 1
            st.markdown("### " + p["name"])
            st.write(p["desc"])
            st.caption(str(p["year"]) + "  ·  " + ", ".join(p["tags"]))
            st.write("")

if shown == 0:
    st.info("No projects match.")

st.divider()
st.caption("Showing " + str(shown) + " of " + str(len(PROJECTS)) + " projects")

# --- Calculator (from Day 1) ---
st.header("Calculator")


def calculate(a, b, op):
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
    raise ValueError("Unknown operator")


x = st.number_input("First number", value=0.0)
y = st.number_input("Second number", value=0.0)
o = st.selectbox("Operation", ["+", "-", "*", "/"])
try:
    st.metric("Result", calculate(x, y, o))
except ValueError as e:
    st.error(str(e))
