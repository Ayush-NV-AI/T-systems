@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
echo ============================================
echo   Starting your app.
echo   First run takes a minute or two.
echo   Leave this window open.
echo ============================================
echo.

rem --- find a Python we can use -------------------------------------------
set "PYEXE="
for %%V in (3.13 3.12 3.11) do (
  if not defined PYEXE (
    py -%%V --version >nul 2>&1 && set "PYEXE=py -%%V"
  )
)
if not defined PYEXE (
  py --version >nul 2>&1 && set "PYEXE=py"
)
if not defined PYEXE (
  python --version >nul 2>&1 && set "PYEXE=python"
)

if not defined PYEXE (
  echo [X] Python is not installed, or not on your PATH.
  echo.
  echo     Install Python 3.12 from https://python.org/downloads
  echo     IMPORTANT: tick "Add Python to PATH" during install.
  echo.
  pause
  exit /b 1
)

for /f "delims=" %%P in ('%PYEXE% -c "import sys;print('%%d.%%d'%%sys.version_info[:2])" 2^>nul') do set "PYVER=%%P"
echo Using Python !PYVER!  (%PYEXE%)
echo.

rem --- create the environment (no activation needed) -----------------------
if not exist ".venv\Scripts\python.exe" (
  echo Creating a private Python environment...
  %PYEXE% -m venv .venv
  if errorlevel 1 (
    echo [X] Could not create the environment. Tell the trainer.
    pause
    exit /b 1
  )
)

rem --- every command below calls the venv python directly ------------------
set "VPY=%CD%\.venv\Scripts\python.exe"

echo Installing Streamlit ^(first run only^)...
"%VPY%" -m pip install --quiet --upgrade pip
"%VPY%" -m pip install --quiet --only-binary=:all: -r requirements.txt
if errorlevel 1 (
  echo.
  echo [X] Install failed.
  echo.
  echo     Most likely cause: your Python version is very new and some
  echo     packages have no prebuilt version for it yet.
  echo     Your Python is !PYVER! - Python 3.12 is the safest.
  echo.
  echo     Second possibility: your network is blocking pip.
  echo.
  echo     Tell the trainer - do not spend the lab on this.
  echo.
  pause
  exit /b 1
)

echo.
echo Opening your app in the browser...
echo To stop it later: close this window.
echo.
"%VPY%" -m streamlit run app.py
pause
