# Lab 2.2 — Find the bug you can see

This is a working portfolio page. Something on it is wrong.

You will see the problem in about ten seconds. Explaining *why* it happens
will take longer — and that gap is the point of this lab.

## Run it

**Replit:** click the link in chat, then the green **Run** button.

**Locally:**
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Step 1 — Reproduce it (6 min)

Use the Projects section. Try the tag filter. Try several different tags.

When you see something wrong, **write down precisely**:

- what you typed
- what you expected to happen
- what happened instead

"The filter is broken" is not precise enough to be useful to anyone,
including you.

## Step 2 — Assemble context before you ask anything (9 min)

Four things, in this order:

1. **What you did and what you expected** — exactly, from step 1
2. **Which files are involved** — name them, let Claude Code read them
3. **What you have already ruled out** — and how you ruled it out
4. **Anything you noticed that seems unrelated** — it may not be

## Step 3 — Ask for five, not one (7 min)

**Do not ask "why is this broken".** Ask for a differential:

```
Here is a bug in my Streamlit app.

WHAT I DID:        <exactly what you typed>
WHAT I EXPECTED:   <exactly what should have happened>
WHAT HAPPENED:     <exactly what did happen>
ALREADY RULED OUT: <what you checked, and how>

Read app.py, data.py and filters.py.

Give me the five most likely root causes, RANKED, and for each one the
cheapest test that would rule it out. Do not fix anything yet.
```

## Step 4 — Work the list (23 min)

Cheapest test first, **not** most-likely first.

Keep a note of what you eliminated and how you eliminated it. That note is
what you'd put in a ticket.

## Step 5 — Fix it, then explain it (10 min)

### The rule

> You may not apply a fix until you can say, **in one sentence**, why this
> bug produces **that exact symptom**.

Finding it by luck doesn't count. If you can't explain the mechanism, you
haven't finished — even if the page now works.

---

## Done when

- The filter behaves correctly for every tag
- You can state the mechanism in one sentence
- You can say why the other four hypotheses were wrong

## Talk to each other — but not about the answer

Share **hypotheses**, not solutions. "I think it might be X, here's why" is
a useful conversation. "It's line 17" ends the lab for both of you.
