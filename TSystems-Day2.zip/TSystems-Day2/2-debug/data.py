"""Project data for the portfolio page."""

PROJECTS = [
    {"name": "Order Reporting Service", "desc": "Internal dashboard for sales ops.",
     "tags": ["python", "api", "dashboard"], "year": 2025},
    {"name": "Bookshelf API", "desc": "A tiny FastAPI app built in a workshop.",
     "tags": ["python", "api"], "year": 2026},
    {"name": "Rapid Prototyping Kit", "desc": "Scaffolding for quick internal demos.",
     "tags": ["rapid", "tooling"], "year": 2024},
    {"name": "Deploy Scripts", "desc": "One-command deploys for the staging box.",
     "tags": ["devops", "tooling"], "year": 2024},
    {"name": "Capacity Planner", "desc": "Spreadsheet replacement for the ops team.",
     "tags": ["python", "dashboard"], "year": 2025},
]

SKILLS = [("Python", "Advanced"), ("SQL", "Intermediate"), ("Docker", "Intermediate")]
