import streamlit as st

from data import PROJECTS, SKILLS
from filters import filter_projects, filter_by_tag

st.set_page_config(page_title="My Portfolio", page_icon="👋", layout="centered")

st.title("Hi, I'm Jordan Lee 👋")
st.subheader("Software Engineer")
st.write("I build backend services and dabble in data tooling.")

st.header("Skills")
for col, (name, level) in zip(st.columns(len(SKILLS)), SKILLS):
    col.metric(name, level)

st.divider()
st.header("Projects")

query = st.text_input("Search projects", "")
tag = st.text_input("Filter by tag (try: api, tooling, python, dashboard)", "")

# How many projects survive the tag filter — used for the summary line below.
tagged = filter_by_tag(PROJECTS, tag)

results = filter_projects(PROJECTS, query, tag)

for p in results:
    st.markdown(f"### {p['name']}")
    st.write(p["desc"])
    st.caption(f"{p['year']}  ·  {', '.join(p['tags'])}")
    st.write("")

if not results:
    st.info("No projects match.")

st.divider()
st.caption(f"Showing {len(tagged)} of {len(PROJECTS)} projects")
