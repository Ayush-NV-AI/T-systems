"""Search and tag filtering for the projects list."""


def matches_search(project, query):
    """True if the query appears in the project name or description."""
    if not query:
        return True
    q = query.lower()
    return q in project["name"].lower() or q in project["desc"].lower()


def matches_tag(project, tag):
    """True if the project carries the given tag."""
    if not tag:
        return True
    return tag.lower() in ",".join(project["tags"]).lower()


def filter_by_tag(projects, tag=""):
    """Every project carrying the given tag."""
    return [p for p in projects if matches_tag(p, tag)]


def filter_projects(projects, query="", tag=""):
    """Return every project matching both the search text and the tag."""
    return [
        p for p in projects
        if matches_search(p, query) and matches_tag(p, tag)
    ]
